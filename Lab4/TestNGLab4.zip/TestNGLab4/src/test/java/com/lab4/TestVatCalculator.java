package com.lab4;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestVatCalculator {

    VatCalculator calc = new VatCalculator();

    @Test
    public void testVat100() {
        Assert.assertEquals(calc.getVatOnAmount(100), 10.0);
    }

    @Test
    public void testVat120() {
        Assert.assertEquals(calc.getVatOnAmount(120), 12.0);
    }
}
