package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelWriter {

    private Workbook workbook;
    private Sheet sheet;
    private int currentRow = 1;

    public ExcelWriter() {
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("TestCases");
        createHeader();
    }

    // ===========================
    // 1) HEADER
    // ===========================
    public void createHeader() {
        Row header = sheet.createRow(0);

        String[] cols = {
            "TC_ID", "Title", "Steps", "Expected", "Actual",
            "Result", "PreCondition", "PostCondition", "Screenshot", "Note"
        };

        for (int i = 0; i < cols.length; i++) {
            Cell cell = header.createCell(i);
            cell.setCellValue(cols[i]);
        }
    }

    // ===========================
    // 2) GHI 1 DÒNG DỮ LIỆU
    // ===========================
    public void writeRow(
        String tcId,
        String title,
        String steps,
        String expected,
        String actual,
        String result,
        String pre,
        String post,
        String screenshot,
        String note
    ) {
        Row row = sheet.createRow(currentRow++);

        row.createCell(0).setCellValue(tcId);
        row.createCell(1).setCellValue(title);
        row.createCell(2).setCellValue(steps);
        row.createCell(3).setCellValue(expected);
        row.createCell(4).setCellValue(actual);
        row.createCell(5).setCellValue(result);
        row.createCell(6).setCellValue(pre);
        row.createCell(7).setCellValue(post);
        row.createCell(8).setCellValue(screenshot);
        row.createCell(9).setCellValue(note);
    }

    // ===========================
    // 3) GHI FILE
    // ===========================
    public void save(String filePath) {
        try (FileOutputStream out = new FileOutputStream(filePath)) {
            workbook.write(out);
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
