package testcase;

import utils.ExcelWriter;

/**
 * ExcelHelper – viết 1 dòng kết quả test vào Excel.
 * 10 cột theo đúng yêu cầu:
 * TC_ID, Title, Steps, Expected, Actual, Result, PreCondition, PostCondition, Screenshot, Note
 */
public class ExcelHelper {

    private static ExcelWriter excel = null;

    /** Khởi tạo ở BaseTest */
    public static void init(ExcelWriter e) {
        excel = e;
    }

    /** Ghi 1 dòng dữ liệu đầy đủ 10 cột */
    public static void write(
            String tcId,
            String title,
            String steps,
            String expected,
            String actual,
            String result,
            String preCondition,
            String postCondition,
            String screenshot,
            String note
    ) {
        if (excel == null) {
            throw new IllegalStateException("ExcelWriter not initialized! Call ExcelHelper.init(excel) first.");
        }
        excel.writeRow(tcId, title, steps, expected, actual, result,
                preCondition, postCondition, screenshot, note);
    }
}
