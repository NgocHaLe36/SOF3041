package test.Junit5Setup;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


public class CalculatorTest {

    Calculator c = new Calculator();

    @Test
    void testAdd() {
        assertEquals(7, c.add(3, 4));      
        assertNotEquals(10, c.add(3, 4));  
    }

    @Test
    void testSubtract() {
        assertEquals(1, c.subtract(5, 4));
        assertTrue(c.subtract(5, 4) == 1);   
        assertFalse(c.subtract(5, 4) == 2);  
    }

    @Test
    void testMultiply() {
        assertEquals(20, c.multiply(4, 5));
        assertNotNull(c.multiply(4, 5));      
    }

    @Test
    void testDivide() {
        assertEquals(2.0, c.divide(10, 5));   

        assertThrows(ArithmeticException.class, () -> {
            c.divide(10, 0);
        });
    }
}
