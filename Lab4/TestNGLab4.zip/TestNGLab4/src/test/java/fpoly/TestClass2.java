package fpoly;

import org.testng.annotations.Test;

public class TestClass2 {

    @Test
    public void case3() {
        System.out.println("TestClass2 - case3");
    }

    @Test
    public void case4() {
        System.out.println("TestClass2 - case4");
    }
}
