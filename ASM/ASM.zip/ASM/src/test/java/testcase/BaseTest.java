package testcase;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import utils.DriverFactory;
import utils.ExcelWriter;

public class BaseTest {

    protected static ExcelWriter excel;

    @BeforeSuite
    public void beforeSuite() {
        try {
            excel = new ExcelWriter();     // constructor tự tạo header
            System.out.println("✔ TestSuite STARTED -> Excel initialized");
        } catch (Exception e) {
            System.out.println("❌ ERROR tạo Excel: " + e.getMessage());
        }
    }

    @AfterSuite(alwaysRun = true)
    public void afterSuite() {
        try {
            String out = "results/TestResult.xlsx";
            excel.save(out);
            System.out.println("✔ Excel SAVED → " + out);
        } catch (Exception e) {
            System.out.println("❌ ERROR lưu Excel: " + e.getMessage());
        }

        try {
            DriverFactory.quitDriver();
            System.out.println("✔ Browser CLOSED");
        } catch (Exception ignored) {}
    }

    /* ======================= PAUSE 3 GIÂY ======================= */
    protected void pause3s() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ignored) {}
    }

    /* ======================= LOGIN HÀM DÙNG CHUNG ======================= */
    protected void loginAs(String id, String password) throws Exception {
        WebDriver driver = DriverFactory.getDriver(false);

        driver.get("http://localhost:8080/PolyLab7/login");
        Thread.sleep(800);

        try { driver.findElement(org.openqa.selenium.By.name("id")).clear(); } catch (Exception ignored) {}
        try { driver.findElement(org.openqa.selenium.By.name("password")).clear(); } catch (Exception ignored) {}

        driver.findElement(org.openqa.selenium.By.name("id")).sendKeys(id);
        driver.findElement(org.openqa.selenium.By.name("password")).sendKeys(password);

        driver.findElement(org.openqa.selenium.By.className("btn-login")).click();
        Thread.sleep(1200);
    }
}
