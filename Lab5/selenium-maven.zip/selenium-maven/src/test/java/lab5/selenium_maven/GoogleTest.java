package lab5.selenium_maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleTest {

    public static void main(String[] args) {

        // Tự động tải ChromeDriver
        WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();

        driver.get("https://www.google.com/");
        System.out.println("Title: " + driver.getTitle());

//        driver.quit();
    }
}
