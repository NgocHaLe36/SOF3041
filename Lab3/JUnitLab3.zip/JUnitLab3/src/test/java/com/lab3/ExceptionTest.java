package com.lab3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ExceptionTest {

    Calculator calc = new Calculator();

    @Test
    void testDivideByZero() {
        assertThrows(ArithmeticException.class, () -> calc.divide(5, 0));
    }

    @Test
    void testNumberFormatException() {
        assertThrows(NumberFormatException.class, () -> {
            Integer.parseInt("ABC");
        });
    }

    @Test
    void testNullPointer() {
        String s = null;
        assertThrows(NullPointerException.class, () -> s.length());
    }
}
