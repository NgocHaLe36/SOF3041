package com.lab4;

public class VatCalculator {

    public double getVatOnAmount(double amount) {
        return amount * 0.10; // 10%
    }
}
