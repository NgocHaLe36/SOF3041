package lab5.selenium_maven;



/**
 * Unit test for simple App.
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AppTest {

    @Test
    void testSomething() {
        assertTrue(true);
    }
}
