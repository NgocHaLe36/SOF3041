package lab6.selenium_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPolyTest {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][]{
                {"admin", "saiPass", "fail", "Sai mật khẩu"},
                {"saiTaiKhoan", "111", "fail", "Sai tài khoản"},
                {"khongTonTai", "saiPass", "fail", "Sai cả tài khoản và mật khẩu"},
                {"", "111", "fail", "Để trống tài khoản"},
                {"admin", "", "fail", "Để trống mật khẩu"},
                {"", "", "fail", "Để trống cả 2 ô"},
                {"admin", "111", "success", "Login đúng"}
        };
    }

    @Test(dataProvider = "loginData")
    public void testLoginMulti(String user, String pass, String expected, String description) {

        driver.get("http://localhost:8080/PolyLab7/login");

        // clear field
        driver.findElement(By.name("id")).clear();
        driver.findElement(By.name("password")).clear();

        // input values
        driver.findElement(By.name("id")).sendKeys(user);
        driver.findElement(By.name("password")).sendKeys(pass);

        driver.findElement(By.className("btn-login")).click();

        String testCaseId = "TC_" + description.replace(" ", "_").toUpperCase();
        String testData = "user=" + user + " | pass=" + pass;
        String actual = "";
        String status = "";

        try {

            if (expected.equals("success")) {

                boolean ok = driver.getCurrentUrl().contains("/admin/dashboard");
                actual = ok ? "Đi đến dashboard" : "Không vào dashboard";

                Assert.assertTrue(ok);
                status = "PASS";

            } else {

                boolean errorShown = false;

                try {
                    errorShown = driver.findElement(By.className("error")).isDisplayed();
                } catch (Exception e) {
                    errorShown = false;
                }

                actual = errorShown ? "Hiện thông báo lỗi" : "Không hiện lỗi";

                Assert.assertTrue(errorShown);
                status = "PASS";
            }

        } catch (AssertionError e) {
            status = "FAIL";
            actual = e.getMessage();
        }

        finally {
            ExcelWriter.writeResult(
                    testCaseId,
                    description,
                    testData,
                    expected,
                    actual,
                    status
            );
        }
    }

    @AfterClass
    public void tearDown() {
        // driver.quit();
    }
}
