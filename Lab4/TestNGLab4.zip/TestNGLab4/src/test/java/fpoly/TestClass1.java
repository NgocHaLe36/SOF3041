package fpoly;

import org.testng.annotations.Test;

public class TestClass1 {

    @Test
    public void case1() {
        System.out.println("TestClass1 - case1");
    }

    @Test
    public void case2() {
        System.out.println("TestClass1 - case2");
    }
}
