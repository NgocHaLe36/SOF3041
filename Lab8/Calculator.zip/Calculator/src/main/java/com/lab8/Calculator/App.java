package com.lab8.Calculator;

/**
 * Hello world!
 *
 */

public class App {
    public static void main(String[] args) {
        Calculator c = new Calculator();

        System.out.println("Add: " + c.add(5, 3));
        System.out.println("Subtract: " + c.subtract(5, 3));
        System.out.println("Multiply: " + c.multiply(5, 3));
        System.out.println("Divide: " + c.divide(10, 2));
    }
}
