package testcase;

import utils.DriverFactory;
import utils.ExcelWriter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginUITest {

    @Test
    public void testAdminLogin() {

        WebDriver driver = DriverFactory.getDriver(false);

        driver.get("http://localhost:8080/PolyLab7/login");

        ExcelWriter excel = new ExcelWriter();
        excel.createHeader();

        try {
            // Nhập username
            driver.findElement(By.name("username")).sendKeys("admin");

            // Nhập password
            driver.findElement(By.name("password")).sendKeys("111");

            // Bấm nút Login
            driver.findElement(By.id("btnLogin")).click();

            // Đợi 1 chút cho redirect
            Thread.sleep(1500);

            // Kiểm tra có vào đúng dashboard chưa
            String currentURL = driver.getCurrentUrl();
            boolean passed = currentURL.contains("/admin/dashboard");

            // Chụp hình sau đăng nhập
            String img = DriverFactory.takeScreenshot("TC01_Login_Admin");

            excel.writeRow(
                "TC01",
                "Login với tài khoản admin",
                "Nhập username/password rồi nhấn Login",
                "Đi vào trang /admin/dashboard",
                passed ? "Dashboard xuất hiện" : "Không vào dashboard",
                passed ? "PASSED" : "FAILED",
                passed ? "" : "Lỗi đăng nhập hoặc sai redirect",
                "Thoát trình duyệt",
                img,
                currentURL
            );

            Assert.assertTrue(passed, "Không redirect vào trang dashboard!");

        } catch (Exception e) {

            // Chụp hình khi lỗi
            String img = DriverFactory.takeScreenshot("TC01_Login_Admin_ERROR");

            excel.writeRow(
                "TC01",
                "Login với admin",
                "Nhập user/pass và nhấn Login",
                "Đi vào dashboard",
                "Không xác định",
                "FAILED",
                e.getMessage(),
                "",
                img,
                ""
            );

            Assert.fail("Test login bị lỗi: " + e.getMessage());
        }

        excel.save("LoginTestResult.xlsx");

        // DriverFactory.quitDriver();
    }
}
