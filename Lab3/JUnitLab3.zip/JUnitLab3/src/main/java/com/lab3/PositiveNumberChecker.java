package com.lab3;

public class PositiveNumberChecker {

    public boolean isPositive(int number) {
        return number > 0;
    }
}
