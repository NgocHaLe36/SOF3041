package fpoly;

import org.testng.annotations.Test;

public class GroupTest {

    @Test(groups = "Regression")
    public void testA() {
        System.out.println("Regression - testA");
    }

    @Test(groups = "Smoke")
    public void testB() {
        System.out.println("Smoke - testB");
    }

    @Test(groups = {"Regression", "Smoke"})
    public void testC() {
        System.out.println("Both groups - testC");
    }

    @Test(groups = "Sanity")
    public void testD() {
        System.out.println("Sanity - testD");
    }
}
