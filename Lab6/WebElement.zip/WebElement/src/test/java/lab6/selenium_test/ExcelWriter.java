package lab6.selenium_test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWriter {

    private static final String FILE_PATH = "target/Login_Test_Result.xlsx";

    public static void writeResult(String testCaseId, String description,
                                   String inputData, String expected,
                                   String actual, String status) {

        try {
            Workbook workbook;
            Sheet sheet;

            File file = new File(FILE_PATH);

            // Nếu file chưa có → tạo mới
            if (!file.exists()) {
                workbook = new XSSFWorkbook();
                sheet = workbook.createSheet("Test Result");

                Row header = sheet.createRow(0);

                String[] cols = {
                        "TEST CASE ID", "DESCRIPTION", "TEST DATA",
                        "EXPECTED RESULT", "ACTUAL RESULT", "STATUS"
                };

                for (int i = 0; i < cols.length; i++) {
                    Cell cell = header.createCell(i);
                    cell.setCellValue(cols[i]);
                    cell.setCellStyle(styleHeader(workbook));
                }

            } else {
                FileInputStream fis = new FileInputStream(file);
                workbook = new XSSFWorkbook(fis);
                sheet = workbook.getSheetAt(0);
                fis.close();
            }

            int lastRow = sheet.getLastRowNum() + 1;
            Row row = sheet.createRow(lastRow);

            row.createCell(0).setCellValue(testCaseId);
            row.createCell(1).setCellValue(description);
            row.createCell(2).setCellValue(inputData);
            row.createCell(3).setCellValue(expected);
            row.createCell(4).setCellValue(actual);
            row.createCell(5).setCellValue(status);

            FileOutputStream out = new FileOutputStream(FILE_PATH);
            workbook.write(out);
            out.close();
            workbook.close();

            System.out.println("✔ Đã ghi dòng vào Excel: " + testCaseId);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static CellStyle styleHeader(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();

        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);

        style.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);

        return style;
    }
}
