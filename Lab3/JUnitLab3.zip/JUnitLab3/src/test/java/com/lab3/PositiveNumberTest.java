package com.lab3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;


public class PositiveNumberTest {

    PositiveNumberChecker checker = new PositiveNumberChecker();

    @ParameterizedTest
    @ValueSource(ints = {1, 5, 10, 99})
    void testPositiveNumbers(int number) {
        assertTrue(checker.isPositive(number));
    }

    @ParameterizedTest
    @ValueSource(ints = {0, -1, -5, -20})
    void testNonPositiveNumbers(int number) {
        assertFalse(checker.isPositive(number));
    }
}
