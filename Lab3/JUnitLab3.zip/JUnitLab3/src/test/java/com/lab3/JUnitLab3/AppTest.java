package com.lab3.JUnitLab3;

import org.junit.jupiter.api.Test;

import com.lab3.Calculator;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

public class AppTest {

    static Calculator calc;

    @BeforeAll
    static void setupAll() {
        System.out.println("=== BEFORE ALL TESTS ===");
        calc = new Calculator();
    }

    @BeforeEach
    void setup() {
        System.out.println("Before Each Test");
    }

    @AfterEach
    void cleanup() {
        System.out.println("After Each Test");
    }

    @AfterAll
    static void cleanupAll() {
        System.out.println("=== AFTER ALL TESTS ===");
    }

    @Test
    void testAdd() {
        assertEquals(7, calc.add(3, 4));
    }

    @Test
    void testSubtract() {
        assertEquals(1, calc.subtract(5, 4));
    }

    @Test
    void testMultiply() {
        assertEquals(20, calc.multiply(4, 5));
    }

    @Test
    void testDivide() {
        assertEquals(2, calc.divide(10, 5));
    }
}