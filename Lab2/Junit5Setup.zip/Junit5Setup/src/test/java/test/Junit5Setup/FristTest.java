package test.Junit5Setup;

import org.junit.jupiter.api.Test;

public class FristTest {
	@Test
	public void demo1(){
		System.out.println("Hello word");
		
	}
}
