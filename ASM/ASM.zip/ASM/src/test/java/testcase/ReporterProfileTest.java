package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import utils.DriverFactory;

/**
 * ReporterProfileTest - 10 test cho chức năng hồ sơ phóng viên
 * Yêu cầu: BaseTest phải có:
 *   - protected static ExcelWriter excel; (được tạo trong @BeforeSuite)
 *   - protected void loginAs(String id, String password) throws Exception;
 *   - protected void pause3s();
 * Và ExcelHelper.init(excel) sẽ được gọi trong @BeforeClass
 */
public class ReporterProfileTest extends BaseTest {

    private WebDriver driver;

    @BeforeClass
    public void beforeClass() {
        // đảm bảo ExcelHelper dùng chung ExcelWriter từ BaseTest
        ExcelHelper.init(excel);
    }

    @BeforeMethod
    public void beforeMethod() throws Exception {
        driver = DriverFactory.getDriver(false);
        // login as reporter to access profile
        loginAs("r001", "111");
        Thread.sleep(700); // nhỏ để redirect
    }

    @AfterMethod
    public void afterMethod() {
        // dừng 3s theo yêu cầu rồi test tiếp
        pause3s();
    }

    @Test
    public void TC21_OpenProfile() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            boolean ok = driver.getPageSource().contains("Hồ sơ cá nhân") 
                      || driver.getPageSource().contains("Hồ sơ") ;
            String img = DriverFactory.takeScreenshot("TC21_OpenProfile");
            ExcelHelper.write(
                    "TC21",
                    "Mở hồ sơ phóng viên",
                    "Truy cập /reporter/profile",
                    "Hiển thị hồ sơ",
                    ok ? "Hiển thị" : "Không hiển thị",
                    ok ? "PASSED" : "FAILED",
                    "Login reporter r001",
                    "",
                    img,
                    ""
            );
            Assert.assertTrue(ok, "Không thấy nội dung Hồ sơ cá nhân");
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC21_Error");
            ExcelHelper.write("TC21",
                    "Mở hồ sơ phóng viên - Lỗi",
                    "Truy cập /reporter/profile",
                    "Hiển thị hồ sơ",
                    "Error: " + e.getMessage(),
                    "FAILED",
                    "Login reporter r001",
                    "",
                    img,
                    e.getMessage()
            );
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC22_UpdateFullname() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            // thay tên full name (field tên có thể là fullname hoặc username tùy implementation)
            try { driver.findElement(By.name("fullname")).clear(); }
            catch (Exception ex) { try { driver.findElement(By.name("username")).clear(); } catch(Exception ignored) {} }

            if (isElementPresent(By.name("fullname"))) {
                driver.findElement(By.name("fullname")).sendKeys("Nguyễn Văn A");
            } else if (isElementPresent(By.name("username"))) {
                driver.findElement(By.name("username")).sendKeys("Nguyễn Văn A");
            }
            // submit
            try { driver.findElement(By.id("btnSave")).click(); } catch (Exception ex) { 
                try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch (Exception ignored) {}
            }
            Thread.sleep(700);
            boolean ok = driver.getPageSource().contains("Cập nhật thành công") || driver.getPageSource().contains("đã cập nhật");
            String img = DriverFactory.takeScreenshot("TC22_UpdateFullname");
            ExcelHelper.write("TC22",
                    "Cập nhật fullname",
                    "Thay fullname -> Nguyễn Văn A",
                    "Hiển thị thông báo Cập nhật thành công",
                    ok ? "Cập nhật thành công" : "Không thấy thông báo",
                    ok ? "PASSED" : "FAILED",
                    "Login reporter r001",
                    "",
                    img,
                    ""
            );
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC22_Error");
            ExcelHelper.write("TC22","Cập nhật fullname - Error","Submit update","Cập nhật thành công","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC23_UpdateEmailValid() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            driver.findElement(By.name("email")).clear();
            driver.findElement(By.name("email")).sendKeys("test.reporter@example.com");
            try { driver.findElement(By.id("btnSave")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(700);
            boolean ok = driver.getPageSource().contains("Cập nhật thành công") || driver.getPageSource().contains("đã cập nhật");
            String img = DriverFactory.takeScreenshot("TC23_UpdateEmail");
            ExcelHelper.write("TC23","Cập nhật email","Nhập email hợp lệ","Cập nhật thành công", ok? "Cập nhật thành công":"Không", ok? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC23_Error");
            ExcelHelper.write("TC23","Cập nhật email - Error","Nhập email hợp lệ","Cập nhật thành công","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC24_UpdateEmailInvalid() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            driver.findElement(By.name("email")).clear();
            driver.findElement(By.name("email")).sendKeys("abc123");
            try { driver.findElement(By.id("btnSave")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(700);
            boolean ok = driver.getPageSource().contains("Email không hợp lệ") || driver.getPageSource().toLowerCase().contains("invalid");
            String img = DriverFactory.takeScreenshot("TC24_InvalidEmail");
            ExcelHelper.write("TC24","Email invalid","Nhập email abc123","Báo lỗi validate", ok? "Hiện":"Không", ok? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC24_Error");
            ExcelHelper.write("TC24","Email invalid - Error","Nhập email abc123","Báo lỗi validate","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC25_EmptyFullname() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            // try fullname or username field
            if (isElementPresent(By.name("fullname"))) {
                driver.findElement(By.name("fullname")).clear();
            } else {
                driver.findElement(By.name("username")).clear();
            }
            try { driver.findElement(By.id("btnSave")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(700);
            boolean ok = driver.getPageSource().contains("không được trống") || driver.getPageSource().toLowerCase().contains("required");
            String img = DriverFactory.takeScreenshot("TC25_EmptyFullname");
            ExcelHelper.write("TC25","Fullname empty","Clear fullname then save","Show validate", ok? "Hiện":"Không", ok? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC25_Error");
            ExcelHelper.write("TC25","Fullname empty - Error","Clear then save","Show validate","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC26_ChangePassword_Success() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            driver.findElement(By.name("password")).clear();
            driver.findElement(By.name("password")).sendKeys("111"); // old
            driver.findElement(By.name("newPassword")).sendKeys("222");
            driver.findElement(By.name("confirmPassword")).sendKeys("222");
            try { driver.findElement(By.id("btnChange")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(700);
            boolean ok = driver.getPageSource().contains("Đổi mật khẩu thành công") || driver.getPageSource().toLowerCase().contains("success");
            String img = DriverFactory.takeScreenshot("TC26_ChangePass");
            ExcelHelper.write("TC26","Đổi mật khẩu đúng","old=111 new=222","Đổi thành công", ok? "Đổi thành công":"Không", ok? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC26_Error");
            ExcelHelper.write("TC26","Change password - Error","Thay mật khẩu","Đổi thành công","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC27_ChangePassword_WrongOld() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            driver.findElement(By.name("password")).clear();
            driver.findElement(By.name("password")).sendKeys("000"); // wrong old
            driver.findElement(By.name("newPassword")).sendKeys("222");
            driver.findElement(By.name("confirmPassword")).sendKeys("222");
            try { driver.findElement(By.id("btnChange")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(700);
            boolean ok = driver.getPageSource().contains("Mật khẩu cũ sai") || driver.getPageSource().toLowerCase().contains("wrong old");
            String img = DriverFactory.takeScreenshot("TC27_WrongOld");
            ExcelHelper.write("TC27","Wrong old password","old=000 new=222","Báo lỗi mật khẩu cũ", ok? "Hiện":"Không", ok? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC27_Error");
            ExcelHelper.write("TC27","Wrong old - Error","Thay mật khẩu","Báo lỗi mật khẩu cũ","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC28_TooShortPassword() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            driver.findElement(By.name("newPassword")).sendKeys("12");
            try { driver.findElement(By.id("btnChange")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(700);
            boolean ok = driver.getPageSource().contains("Mật khẩu quá ngắn") || driver.getPageSource().toLowerCase().contains("too short");
            String img = DriverFactory.takeScreenshot("TC28_TooShort");
            ExcelHelper.write("TC28","Short password","new=12","Báo lỗi validate", ok? "Hiện":"Không", ok? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC28_Error");
            ExcelHelper.write("TC28","Too short - Error","Thay mật khẩu","Báo lỗi validate","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC29_UploadAvatar() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            // path on your machine; adjust to a real image path
            driver.findElement(By.name("avatar")).sendKeys("C:\\fakepath\\avatar.png");
            try { driver.findElement(By.id("btnUpload")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(800);
            boolean ok = driver.getPageSource().contains("Tải ảnh thành công") || driver.getPageSource().toLowerCase().contains("upload success");
            String img = DriverFactory.takeScreenshot("TC29_UploadAvatar");
            ExcelHelper.write("TC29","Upload avatar",".png small","Tải ảnh thành công", ok? "OK":"Không", ok? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(ok);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC29_Error");
            ExcelHelper.write("TC29","Upload avatar - Error","Upload file","Tải ảnh thành công","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void TC30_Profile_SQLInject() {
        try {
            driver.get("http://localhost:8080/PolyLab7/reporter/profile");
            // thử payload SQLi
            if (isElementPresent(By.name("username"))) {
                driver.findElement(By.name("username")).clear();
                driver.findElement(By.name("username")).sendKeys("' OR ''='");
            } else if (isElementPresent(By.name("fullname"))) {
                driver.findElement(By.name("fullname")).clear();
                driver.findElement(By.name("fullname")).sendKeys("' OR ''='");
            }
            try { driver.findElement(By.id("btnSave")).click(); } catch (Exception ex) { try { driver.findElement(By.cssSelector("button[type='submit']")).click(); } catch(Exception ignored) {} }
            Thread.sleep(700);
            boolean safe = !driver.getPageSource().toLowerCase().contains("sql") && !driver.getPageSource().toLowerCase().contains("exception");
            String img = DriverFactory.takeScreenshot("TC30_SQLInject");
            ExcelHelper.write("TC30","Profile SQL injection","Nhập ' OR ''='","Không để lộ SQL/Exception", safe? "OK":"Có lỗi", safe? "PASSED":"FAILED","Login reporter","","",img);
            Assert.assertTrue(safe);
        } catch (Exception e) {
            String img = DriverFactory.takeScreenshot("TC30_Error");
            ExcelHelper.write("TC30","SQLInject profile - Error","Nhập payload","Không để lộ SQL/Exception","Error: "+e.getMessage(),"FAILED","Login reporter","",img,e.getMessage());
            Assert.fail(e.getMessage());
        }
    }

    /** helper: kiểm tra element có tồn tại không (không ném exception) */
    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
